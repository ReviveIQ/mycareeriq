import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { applicationRouter } from "./applicationRouter";
import { applicationStatusRouter } from "./applicationStatusRouter";
import { applicationHistoryRouter } from "./applicationHistoryRouter";
import { researchConfigRouter } from "./researchConfigRouter";
import { emailLookupRouter } from "./emailLookupRouter";
import { monitoringRouter } from "./monitoringRouter";
import { pipelineRouter } from "./pipelineRouter";
import { workspaceRouter } from "./workspaceRouter";
import { workspaceMemberRouter } from "./workspaceMemberRouter";
import { workspaceMigrationRouter } from "./workspaceMigrationRouter";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  application: applicationRouter,
  applicationStatus: applicationStatusRouter,
  applicationHistory: applicationHistoryRouter,
  researchConfig: researchConfigRouter,
  emailLookup: emailLookupRouter,
  monitoring: monitoringRouter,
  pipeline: pipelineRouter,
  workspace: workspaceRouter,
  workspaceMember: workspaceMemberRouter,
  workspaceMigration: workspaceMigrationRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
